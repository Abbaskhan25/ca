import React from 'react';
import Header from './components/Header';
import Calculator from './components/Calculator';
import Features from './components/Features';
import Footer from './components/Footer';
import AdSpace from './components/AdSpace';

function App() {
  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <main className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="grid lg:grid-cols-4 gap-8">
          {/* Left Sidebar - Ad Space */}
          <div className="hidden lg:block">
            <div className="sticky top-8">
              <AdSpace size="sidebar" className="mb-6" />
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <h3 className="font-semibold text-gray-900 mb-3">Quick Tips</h3>
                <ul className="text-sm text-gray-600 space-y-2">
                  <li>• Use keyboard shortcuts for faster input</li>
                  <li>• Toggle between RAD and DEG modes</li>
                  <li>• Access calculation history anytime</li>
                  <li>• Use memory functions for complex calculations</li>
                </ul>
              </div>
            </div>
          </div>

          {/* Main Calculator */}
          <div className="lg:col-span-2">
            <div id="calculator" className="text-center mb-8">
              <h1 className="text-4xl font-bold text-gray-900 mb-4">
                Scientific Calculator
              </h1>
              <p className="text-lg text-gray-600 max-w-2xl mx-auto">
                Powerful scientific calculator with advanced mathematical functions, 
                memory operations, and calculation history.
              </p>
            </div>
            
            <div className="flex justify-center mb-8">
              <Calculator />
            </div>

            {/* Mobile Ad */}
            <div className="lg:hidden mb-8 flex justify-center">
              <AdSpace size="rectangle" />
            </div>
          </div>

          {/* Right Sidebar - Ad Space */}
          <div className="hidden lg:block">
            <div className="sticky top-8">
              <AdSpace size="sidebar" className="mb-6" />
              <div className="bg-white p-6 rounded-xl shadow-sm">
                <h3 className="font-semibold text-gray-900 mb-3">Mathematical Functions</h3>
                <div className="text-sm text-gray-600 space-y-2">
                  <div className="flex justify-between">
                    <span>sin, cos, tan</span>
                    <span className="text-gray-400">Trigonometry</span>
                  </div>
                  <div className="flex justify-between">
                    <span>log, ln</span>
                    <span className="text-gray-400">Logarithms</span>
                  </div>
                  <div className="flex justify-between">
                    <span>√, x²</span>
                    <span className="text-gray-400">Powers</span>
                  </div>
                  <div className="flex justify-between">
                    <span>π, e</span>
                    <span className="text-gray-400">Constants</span>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Features />
      
      <section id="about" className="py-16 bg-white">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 text-center">
          <h2 className="text-3xl font-bold text-gray-900 mb-6">About ScientificCalc Pro</h2>
          <div className="grid md:grid-cols-2 gap-8 items-center">
            <div className="text-left">
              <p className="text-gray-600 mb-4">
                ScientificCalc Pro is a comprehensive online scientific calculator designed for students, 
                engineers, scientists, and anyone who needs to perform complex mathematical calculations.
              </p>
              <p className="text-gray-600 mb-4">
                Our calculator supports all standard mathematical operations along with advanced functions 
                like trigonometry, logarithms, exponentials, and more. With its intuitive interface and 
                responsive design, you can perform calculations efficiently on any device.
              </p>
              <p className="text-gray-600">
                Whether you're solving homework problems, conducting research, or working on engineering 
                projects, ScientificCalc Pro provides the precision and functionality you need.
              </p>
            </div>
            <div className="flex justify-center">
              <AdSpace size="rectangle" />
            </div>
          </div>
        </div>
      </section>

      <Footer />
    </div>
  );
}

export default App;