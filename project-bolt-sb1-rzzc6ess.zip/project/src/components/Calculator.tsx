import React, { useState, useCallback, useEffect } from 'react';
import { History, RotateCcw, Delete } from 'lucide-react';

interface CalculatorState {
  display: string;
  previousValue: string;
  operation: string;
  waitingForNewValue: boolean;
  memory: number;
  history: string[];
  showHistory: boolean;
}

const Calculator: React.FC = () => {
  const [state, setState] = useState<CalculatorState>({
    display: '0',
    previousValue: '',
    operation: '',
    waitingForNewValue: false,
    memory: 0,
    history: [],
    showHistory: false,
  });

  const [isRadians, setIsRadians] = useState(true);

  const calculate = useCallback((expression: string): number => {
    try {
      // Replace display-friendly symbols with JavaScript operators
      let expr = expression
        .replace(/×/g, '*')
        .replace(/÷/g, '/')
        .replace(/π/g, Math.PI.toString())
        .replace(/e/g, Math.E.toString());
      
      // Handle scientific functions
      expr = expr.replace(/sin\(/g, `Math.sin(${isRadians ? '' : 'Math.PI/180*'}`);
      expr = expr.replace(/cos\(/g, `Math.cos(${isRadians ? '' : 'Math.PI/180*'}`);
      expr = expr.replace(/tan\(/g, `Math.tan(${isRadians ? '' : 'Math.PI/180*'}`);
      expr = expr.replace(/log\(/g, 'Math.log10(');
      expr = expr.replace(/ln\(/g, 'Math.log(');
      expr = expr.replace(/√\(/g, 'Math.sqrt(');
      expr = expr.replace(/\^/g, '**');

      const result = Function('"use strict"; return (' + expr + ')')();
      return isFinite(result) ? result : NaN;
    } catch {
      return NaN;
    }
  }, [isRadians]);

  const updateDisplay = (newDisplay: string) => {
    setState(prev => ({ ...prev, display: newDisplay }));
  };

  const inputNumber = (num: string) => {
    setState(prev => ({
      ...prev,
      display: prev.waitingForNewValue ? num : prev.display === '0' ? num : prev.display + num,
      waitingForNewValue: false,
    }));
  };

  const inputOperator = (nextOperator: string) => {
    const inputValue = parseFloat(state.display);

    if (state.previousValue === '') {
      setState(prev => ({
        ...prev,
        previousValue: state.display,
        operation: nextOperator,
        waitingForNewValue: true,
      }));
    } else if (state.operation) {
      const currentValue = parseFloat(state.previousValue);
      const newValue = calculate(`${currentValue} ${state.operation} ${inputValue}`);

      setState(prev => ({
        ...prev,
        display: String(newValue),
        previousValue: String(newValue),
        operation: nextOperator,
        waitingForNewValue: true,
        history: [...prev.history, `${currentValue} ${state.operation} ${inputValue} = ${newValue}`],
      }));
    }
  };

  const performCalculation = () => {
    if (state.operation && state.previousValue !== '') {
      const inputValue = parseFloat(state.display);
      const currentValue = parseFloat(state.previousValue);
      const result = calculate(`${currentValue} ${state.operation} ${inputValue}`);
      
      setState(prev => ({
        ...prev,
        display: String(result),
        previousValue: '',
        operation: '',
        waitingForNewValue: true,
        history: [...prev.history, `${currentValue} ${state.operation} ${inputValue} = ${result}`],
      }));
    }
  };

  const performScientificOperation = (func: string) => {
    const value = parseFloat(state.display);
    let result: number;

    switch (func) {
      case 'sin':
        result = Math.sin(isRadians ? value : (value * Math.PI) / 180);
        break;
      case 'cos':
        result = Math.cos(isRadians ? value : (value * Math.PI) / 180);
        break;
      case 'tan':
        result = Math.tan(isRadians ? value : (value * Math.PI) / 180);
        break;
      case 'log':
        result = Math.log10(value);
        break;
      case 'ln':
        result = Math.log(value);
        break;
      case 'sqrt':
        result = Math.sqrt(value);
        break;
      case 'square':
        result = value * value;
        break;
      case 'inverse':
        result = 1 / value;
        break;
      case 'factorial':
        result = value <= 0 ? 1 : Array.from({ length: value }, (_, i) => i + 1).reduce((a, b) => a * b, 1);
        break;
      default:
        result = value;
    }

    setState(prev => ({
      ...prev,
      display: String(result),
      waitingForNewValue: true,
      history: [...prev.history, `${func}(${value}) = ${result}`],
    }));
  };

  const clear = () => {
    setState(prev => ({
      ...prev,
      display: '0',
      previousValue: '',
      operation: '',
      waitingForNewValue: false,
    }));
  };

  const clearEntry = () => {
    updateDisplay('0');
  };

  const backspace = () => {
    if (state.display.length > 1) {
      updateDisplay(state.display.slice(0, -1));
    } else {
      updateDisplay('0');
    }
  };

  const toggleSign = () => {
    if (state.display !== '0') {
      updateDisplay(state.display.startsWith('-') ? state.display.slice(1) : '-' + state.display);
    }
  };

  const insertConstant = (constant: string) => {
    setState(prev => ({
      ...prev,
      display: prev.waitingForNewValue ? constant : prev.display + constant,
      waitingForNewValue: false,
    }));
  };

  // Memory operations
  const memoryAdd = () => {
    setState(prev => ({ ...prev, memory: prev.memory + parseFloat(state.display) }));
  };

  const memorySubtract = () => {
    setState(prev => ({ ...prev, memory: prev.memory - parseFloat(state.display) }));
  };

  const memoryRecall = () => {
    updateDisplay(String(state.memory));
  };

  const memoryClear = () => {
    setState(prev => ({ ...prev, memory: 0 }));
  };

  useEffect(() => {
    const handleKeyPress = (event: KeyboardEvent) => {
      const { key } = event;
      if ('0123456789'.includes(key)) {
        inputNumber(key);
      } else if ('+-*/'.includes(key)) {
        inputOperator(key === '*' ? '×' : key === '/' ? '÷' : key);
      } else if (key === 'Enter' || key === '=') {
        performCalculation();
      } else if (key === 'Escape') {
        clear();
      } else if (key === 'Backspace') {
        backspace();
      } else if (key === '.') {
        if (!state.display.includes('.')) {
          inputNumber('.');
        }
      }
    };

    window.addEventListener('keydown', handleKeyPress);
    return () => window.removeEventListener('keydown', handleKeyPress);
  }, [state]);

  const Button: React.FC<{
    onClick: () => void;
    className?: string;
    children: React.ReactNode;
  }> = ({ onClick, className = '', children }) => (
    <button
      onClick={onClick}
      className={`rounded-lg font-semibold transition-all duration-150 hover:scale-105 active:scale-95 h-12 md:h-16 text-base md:text-lg ${className}`}
    >
      {children}
    </button>
  );

  return (
    <div className="w-full max-w-[1000px] mx-auto bg-gray-900 rounded-2xl shadow-2xl overflow-hidden">
      {/* Display */}
      <div className="bg-gray-800 p-6">
        <div className="text-right">
          <div className="text-gray-400 text-sm h-6">
            {state.previousValue && state.operation && `${state.previousValue} ${state.operation}`}
          </div>
          <div className="text-white text-4xl font-light overflow-hidden">
            {state.display}
          </div>
        </div>
        <div className="flex justify-between items-center mt-4">
          <div className="flex space-x-2">
            <button
              onClick={() => setIsRadians(!isRadians)}
              className="px-3 py-1 rounded text-xs bg-gray-700 text-white hover:bg-gray-600"
            >
              {isRadians ? 'RAD' : 'DEG'}
            </button>
            <span className="text-gray-400 text-xs">M: {state.memory}</span>
          </div>
          <button
            onClick={() => setState(prev => ({ ...prev, showHistory: !prev.showHistory }))}
            className="p-2 text-gray-400 hover:text-white"
          >
            <History size={16} />
          </button>
        </div>
      </div>

      {/* History Panel */}
      {state.showHistory && (
        <div className="bg-gray-750 border-t border-gray-700 max-h-48 overflow-y-auto">
          <div className="p-4">
            <div className="flex justify-between items-center mb-2">
              <h3 className="text-white text-sm font-semibold">History</h3>
              <button
                onClick={() => setState(prev => ({ ...prev, history: [] }))}
                className="text-gray-400 hover:text-white"
              >
                <RotateCcw size={14} />
              </button>
            </div>
            {state.history.length === 0 ? (
              <p className="text-gray-400 text-xs">No calculations yet</p>
            ) : (
              <div className="space-y-1">
                {state.history.slice(-10).map((calc, index) => (
                  <div key={index} className="text-gray-300 text-xs font-mono">
                    {calc}
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      )}

      {/* Button Grid */}
      <div className="p-6 grid grid-cols-5 gap-4">
        {/* Row 1 - Scientific Functions */}
        <Button onClick={() => performScientificOperation('sin')} className="bg-blue-600 hover:bg-blue-500 text-white">
          sin
        </Button>
        <Button onClick={() => performScientificOperation('cos')} className="bg-blue-600 hover:bg-blue-500 text-white">
          cos
        </Button>
        <Button onClick={() => performScientificOperation('tan')} className="bg-blue-600 hover:bg-blue-500 text-white">
          tan
        </Button>
        <Button onClick={() => performScientificOperation('log')} className="bg-blue-600 hover:bg-blue-500 text-white">
          log
        </Button>
        <Button onClick={() => performScientificOperation('ln')} className="bg-blue-600 hover:bg-blue-500 text-white">
          ln
        </Button>

        {/* Row 2 - More Functions */}
        <Button onClick={() => inputOperator('^')} className="bg-blue-600 hover:bg-blue-500 text-white">
          x^y
        </Button>
        <Button onClick={() => performScientificOperation('square')} className="bg-blue-600 hover:bg-blue-500 text-white">
          x²
        </Button>
        <Button onClick={() => performScientificOperation('sqrt')} className="bg-blue-600 hover:bg-blue-500 text-white">
          √
        </Button>
        <Button onClick={() => performScientificOperation('inverse')} className="bg-blue-600 hover:bg-blue-500 text-white">
          1/x
        </Button>
        <Button onClick={() => performScientificOperation('factorial')} className="bg-blue-600 hover:bg-blue-500 text-white">
          x!
        </Button>

        {/* Row 3 - Memory & Clear */}
        <Button onClick={memoryClear} className="bg-gray-600 hover:bg-gray-500 text-white">
          MC
        </Button>
        <Button onClick={memoryRecall} className="bg-gray-600 hover:bg-gray-500 text-white">
          MR
        </Button>
        <Button onClick={memoryAdd} className="bg-gray-600 hover:bg-gray-500 text-white">
          M+
        </Button>
        <Button onClick={memorySubtract} className="bg-gray-600 hover:bg-gray-500 text-white">
          M-
        </Button>
        <Button onClick={clear} className="bg-red-600 hover:bg-red-500 text-white">
          AC
        </Button>

        {/* Row 4 - Constants & Operations */}
        <Button onClick={() => insertConstant('π')} className="bg-purple-600 hover:bg-purple-500 text-white">
          π
        </Button>
        <Button onClick={() => insertConstant('e')} className="bg-purple-600 hover:bg-purple-500 text-white">
          e
        </Button>
        <Button onClick={clearEntry} className="bg-gray-600 hover:bg-gray-500 text-white">
          CE
        </Button>
        <Button onClick={backspace} className="bg-gray-600 hover:bg-gray-500 text-white flex items-center justify-center">
          <Delete size={16} />
        </Button>
        <Button onClick={() => inputOperator('÷')} className="bg-orange-600 hover:bg-orange-500 text-white">
          ÷
        </Button>

        {/* Row 5 - Numbers */}
        <Button onClick={() => inputNumber('7')} className="bg-gray-700 hover:bg-gray-600 text-white">
          7
        </Button>
        <Button onClick={() => inputNumber('8')} className="bg-gray-700 hover:bg-gray-600 text-white">
          8
        </Button>
        <Button onClick={() => inputNumber('9')} className="bg-gray-700 hover:bg-gray-600 text-white">
          9
        </Button>
        <Button onClick={() => inputNumber('(')} className="bg-gray-600 hover:bg-gray-500 text-white">
          (
        </Button>
        <Button onClick={() => inputOperator('×')} className="bg-orange-600 hover:bg-orange-500 text-white">
          ×
        </Button>

        {/* Row 6 - Numbers */}
        <Button onClick={() => inputNumber('4')} className="bg-gray-700 hover:bg-gray-600 text-white">
          4
        </Button>
        <Button onClick={() => inputNumber('5')} className="bg-gray-700 hover:bg-gray-600 text-white">
          5
        </Button>
        <Button onClick={() => inputNumber('6')} className="bg-gray-700 hover:bg-gray-600 text-white">
          6
        </Button>
        <Button onClick={() => inputNumber(')')} className="bg-gray-600 hover:bg-gray-500 text-white">
          )
        </Button>
        <Button onClick={() => inputOperator('-')} className="bg-orange-600 hover:bg-orange-500 text-white">
          −
        </Button>

        {/* Row 7 - Numbers */}
        <Button onClick={() => inputNumber('1')} className="bg-gray-700 hover:bg-gray-600 text-white">
          1
        </Button>
        <Button onClick={() => inputNumber('2')} className="bg-gray-700 hover:bg-gray-600 text-white">
          2
        </Button>
        <Button onClick={() => inputNumber('3')} className="bg-gray-700 hover:bg-gray-600 text-white">
          3
        </Button>
        <Button onClick={toggleSign} className="bg-gray-600 hover:bg-gray-500 text-white">
          ±
        </Button>
        <Button onClick={() => inputOperator('+')} className="bg-orange-600 hover:bg-orange-500 text-white">
          +
        </Button>

        {/* Row 8 - Bottom Row */}
        <Button onClick={() => inputNumber('0')} className="bg-gray-700 hover:bg-gray-600 text-white col-span-2">
          0
        </Button>
        <Button onClick={() => inputNumber('.')} className="bg-gray-700 hover:bg-gray-600 text-white">
          .
        </Button>
        <Button onClick={performCalculation} className="bg-orange-600 hover:bg-orange-500 text-white col-span-2">
          =
        </Button>
      </div>
    </div>
  );
};

export default Calculator;