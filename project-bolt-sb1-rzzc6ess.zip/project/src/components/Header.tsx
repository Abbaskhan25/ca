import React from 'react';
import { Calculator } from 'lucide-react';
import AdSpace from './AdSpace';

const Header: React.FC = () => {
  return (
    <header className="bg-white shadow-sm border-b border-gray-200">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex items-center justify-between h-16">
          <div className="flex items-center space-x-3">
            <div className="flex items-center justify-center w-10 h-10 bg-blue-600 rounded-lg">
              <Calculator className="w-6 h-6 text-white" />
            </div>
            <div>
              <h1 className="text-xl font-bold text-gray-900">ScientificCalc Pro</h1>
              <p className="text-xs text-gray-500">Advanced Scientific Calculator</p>
            </div>
          </div>
          
          <nav className="hidden md:flex space-x-8">
            <a href="#calculator" className="text-gray-600 hover:text-gray-900 transition-colors">Calculator</a>
            <a href="#features" className="text-gray-600 hover:text-gray-900 transition-colors">Features</a>
            <a href="#about" className="text-gray-600 hover:text-gray-900 transition-colors">About</a>
          </nav>
        </div>
      </div>
      
      {/* Header Ad Banner */}
      <div className="border-t border-gray-100 py-4">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 flex justify-center">
          <AdSpace size="banner" />
        </div>
      </div>
    </header>
  );
};

export default Header;