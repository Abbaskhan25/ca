import React from 'react';

interface AdSpaceProps {
  size: 'banner' | 'rectangle' | 'sidebar' | 'mobile';
  className?: string;
}

const AdSpace: React.FC<AdSpaceProps> = ({ size, className = '' }) => {
  const getSizeClasses = () => {
    switch (size) {
      case 'banner':
        return 'w-full h-24 md:h-20'; // 728x90 equivalent
      case 'rectangle':
        return 'w-80 h-64'; // 300x250 equivalent
      case 'sidebar':
        return 'w-40 h-96'; // 160x600 equivalent
      case 'mobile':
        return 'w-full h-16'; // 320x50 equivalent
      default:
        return 'w-full h-20';
    }
  };

  return (
    <div className={`${getSizeClasses()} bg-gradient-to-r from-gray-100 to-gray-200 border-2 border-dashed border-gray-300 rounded-lg flex items-center justify-center ${className}`}>
      <div className="text-center">
        <div className="text-gray-400 text-xs font-medium mb-1">Advertisement</div>
        <div className="text-gray-500 text-xs">Google AdSense</div>
      </div>
    </div>
  );
};

export default AdSpace;